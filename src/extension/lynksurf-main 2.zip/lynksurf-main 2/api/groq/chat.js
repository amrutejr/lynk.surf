// api/groq/chat.js
// Vercel Serverless function — proxies requests to GROQ/OpenAI-style endpoint
// Make sure to set GROQ_API_KEY and BACKEND_CLIENT_KEY in Vercel env

export default async function handler(req, res) {
  // Always set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-extension-key');

  // Handle OPTIONS preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Basic incoming checks
    const BACKEND_CLIENT_KEY = process.env.BACKEND_CLIENT_KEY || '';
    const clientKey = req.headers['x-extension-key'] || '';

    if (BACKEND_CLIENT_KEY && clientKey !== BACKEND_CLIENT_KEY) {
      return res.status(401).json({ error: 'Unauthorized: invalid extension key' });
    }

    // Basic body validation
    const body = req.body;
    if (!body || !body.model || !Array.isArray(body.messages)) {
      return res.status(400).json({ error: 'Invalid request body: expected { model, messages }' });
    }

    // Forward to Groq/OpenAI-like endpoint
    const GROQ_API_ENDPOINT = process.env.GROQ_API_ENDPOINT || 'https://api.groq.com/openai/v1/chat/completions';
    const GROQ_API_KEY = process.env.GROQ_API_KEY;

    if (!GROQ_API_KEY) {
      console.error('Server misconfigured: missing GROQ_API_KEY');
      return res.status(500).json({ error: 'Server configuration error' });
    }

    // Build payload - restrict max tokens client can request to avoid abuse
    const safePayload = {
      model: body.model,
      messages: body.messages,
      temperature: Number(body.temperature ?? 0.7),
      max_tokens: Math.min(Number(body.max_tokens ?? 150), 800), // cap
      top_p: Number(body.top_p ?? 0.9),
      stream: false
    };

    const response = await fetch(GROQ_API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify(safePayload)
    });

    // Handle upstream errors
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Groq API error (${response.status}):`, errorText);
      try {
        const errorJson = JSON.parse(errorText);
        return res.status(response.status).json(errorJson);
      } catch {
        return res.status(response.status).json({ error: `Upstream error: ${response.statusText}`, details: errorText });
      }
    }

    const data = await response.json();
    return res.status(200).json(data);

  } catch (err) {
    console.error('Proxy error:', err);
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
}

