/**
 * LynkSurf Popup Script
 * Handles tab navigation, tone selection, and post enhancement
 */

let selectedTone = 'professional';

// Configuration
const BACKEND_AI_ENDPOINT = 'https://linksurf-k5dc3qpuh-abhinavs-projects-938b3e6e.vercel.app/api/groq/chat';
const BACKEND_CLIENT_KEY = '45ed4e3181fe023c34841cebc858e28fb7fa3c8b1f5f016692b06e44bd7fd3bf';

// Initialize when popup opens
document.addEventListener('DOMContentLoaded', () => {
  console.log('🧠 LinkSage: Popup DOMContentLoaded event fired');

  // Debug: Check storage immediately
  chrome.storage.local.get(null, (allData) => {
    console.log('🧠 LinkSage: All storage data:', allData);
  });

  initializeTabs();
  initializeToneCards();
  initializeButtons();
  loadSettings();
  loadProfiles();
  initializeCustomMessage();
  initializeExport();
  initializeProfileActions();

  // Refresh profiles when popup gains focus
  window.addEventListener('focus', loadProfiles);

  // Listen for profile updates from content script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'profileSaved') {
      console.log('🧠 LinkSage: Profile saved notification received, refreshing table');
      loadProfiles();
    }
  });
});

/**
 * Initialize tab switching functionality
 */
function initializeTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabName = btn.getAttribute('data-tab');

      // Remove active class from all tabs and panes
      tabBtns.forEach(b => b.classList.remove('active'));
      tabPanes.forEach(p => p.classList.remove('active'));

      // Add active class to clicked tab and corresponding pane
      btn.classList.add('active');
      document.getElementById(`${tabName}-tab`).classList.add('active');
    });
  });
}

/**
 * Initialize tone card selection
 */
function initializeToneCards() {
  const toneCards = document.querySelectorAll('.tone-card');

  toneCards.forEach(card => {
    card.addEventListener('click', () => {
      // Remove selected class from all cards
      toneCards.forEach(c => c.classList.remove('selected'));

      // Add selected class to clicked card
      card.classList.add('selected');
      selectedTone = card.getAttribute('data-tone');

      // Save to storage
      chrome.storage.local.set({ selectedTone });
    });
  });
}

/**
 * Initialize button event listeners
 */
function initializeButtons() {
  const closeBtn = document.getElementById('closeBtn');
  const saveBtn = document.getElementById('enhanceBtn');
  const testBtn = document.getElementById('testAddProfileBtn');

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      window.close();
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', saveChanges);
  }

  if (testBtn) {
    testBtn.addEventListener('click', () => {
      console.log('🧠 LinkSage: Test button clicked');
      const testProfile = {
        name: 'John Doe',
        email: 'john.doe@example.com',
        headline: 'Software Engineer',
        location: 'San Francisco, CA',
        profileUrl: 'https://linkedin.com/in/johndoe',
        savedAt: new Date().toISOString()
      };

      chrome.storage.local.get(['savedProfiles'], (result) => {
        const profiles = result.savedProfiles || [];
        profiles.push(testProfile);
        chrome.storage.local.set({ savedProfiles: profiles }, () => {
          console.log('🧠 LinkSage: Test profile added');
          loadProfiles();
        });
      });
    });
  }
}

/**
 * Initialize event delegation for profile actions (View, Edit, Delete)
 */
function initializeProfileActions() {
  const tableBody = document.getElementById('profilesTableBody');
  if (!tableBody) return;

  tableBody.addEventListener('click', (e) => {
    const target = e.target;
    // Handle clicks on the button or its children (icon)
    const btn = target.closest('button');

    if (!btn) return;

    const row = btn.closest('tr');
    if (!row) return;

    const index = parseInt(row.getAttribute('data-index'), 10);
    if (isNaN(index)) return;

    if (btn.classList.contains('view-btn')) {
      console.log('🧠 LinkSage: View button clicked for index', index);
      viewProfile(index);
    } else if (btn.classList.contains('edit-btn')) {
      console.log('🧠 LinkSage: Edit button clicked for index', index);
      editProfile(index);
    } else if (btn.classList.contains('delete-btn')) {
      console.log('🧠 LinkSage: Delete button clicked for index', index);
      deleteProfile(index);
    } else if (btn.classList.contains('save-btn')) {
      console.log('🧠 LinkSage: Save button clicked for index', index);
      saveProfile(index);
    } else if (btn.classList.contains('cancel-btn')) {
      console.log('🧠 LinkSage: Cancel button clicked for index', index);
      cancelEdit(index);
    }
  });
}

/**
 * Load saved settings from chrome.storage.local
 */
function loadSettings() {
  chrome.storage.local.get(['selectedTone'], (result) => {
    if (result.selectedTone) {
      selectedTone = result.selectedTone;
      const card = document.querySelector(`[data-tone="${selectedTone}"]`);
      if (card) {
        card.classList.add('selected');
      }
    } else {
      // Default to professional
      const card = document.querySelector('[data-tone="professional"]');
      if (card) {
        card.classList.add('selected');
      }
    }
  });
}

/**
 * Save the selected tone changes
 */
function saveChanges() {
  const saveBtn = document.getElementById('enhanceBtn');
  saveBtn.disabled = true;
  saveBtn.innerHTML = '<span class="btn-icon">✨</span><span>Saving...</span>';

  // Save the selected tone to storage
  chrome.storage.local.set({ selectedTone }, () => {
    saveBtn.disabled = false;
    saveBtn.innerHTML = '<span class="btn-icon">✨</span><span>Save Changes</span>';

    // Show confirmation
    alert('Changes saved successfully!');
  });
}

/**
 * Load profiles from storage and display in table
 */
function loadProfiles() {
  console.log('🧠 LinkSage: loadProfiles called');

  // Add a small delay to ensure DOM is ready
  setTimeout(() => {
    chrome.storage.local.get(['savedProfiles'], (result) => {
      const profiles = result.savedProfiles || [];
      console.log('🧠 LinkSage: Loaded profiles from storage:', profiles);
      console.log('🧠 LinkSage: Number of profiles:', profiles.length);
      displayProfiles(profiles);
    });
  }, 100);
}

/**
 * Display profiles in the table
 */
function displayProfiles(profiles) {
  const tableBody = document.getElementById('profilesTableBody');

  if (!tableBody) {
    console.error('🧠 LinkSage: profilesTableBody element not found!');
    return;
  }

  console.log('🧠 LinkSage: displayProfiles called with', profiles?.length || 0, 'profiles');

  if (!profiles || profiles.length === 0) {
    console.log('🧠 LinkSage: No profiles to display, showing empty message');
    tableBody.innerHTML = '<tr class="empty-row"><td colspan="3">No profiles saved yet</td></tr>';
    return;
  }

  console.log('🧠 LinkSage: Rendering', profiles.length, 'profiles');

  tableBody.innerHTML = profiles.map((profile, index) => {
    console.log(`🧠 LinkSage: Rendering profile ${index}:`, profile.name, profile.email);
    return `
    <tr data-index="${index}">
      <td class="profile-name-cell">
        <span class="profile-name-text">${escapeHtml(profile.name || 'Unknown')}</span>
      </td>
      <td class="profile-email-cell">
        <span class="profile-email-text">${escapeHtml(profile.email || 'No email')}</span>
      </td>
      <td>
        <div class="profile-actions">
          <button class="action-btn view-btn" title="View Profile">👁️</button>
          <button class="action-btn edit-btn" title="Edit">✏️</button>
          <button class="action-btn delete-btn" title="Delete">🗑️</button>
        </div>
      </td>
    </tr>
  `;
  }).join('');
}

/**
 * View a profile by opening its LinkedIn URL
 */
function viewProfile(index) {
  chrome.storage.local.get(['savedProfiles'], (result) => {
    const profiles = result.savedProfiles || [];
    const profile = profiles[index];

    if (profile && profile.profileUrl) {
      chrome.tabs.create({ url: profile.profileUrl });
    } else {
      alert('Profile URL not available');
    }
  });
}

/**
 * Edit a profile
 */
function editProfile(index) {
  chrome.storage.local.get(['savedProfiles'], (result) => {
    const profiles = result.savedProfiles || [];
    const profile = profiles[index];

    const row = document.querySelector(`tr[data-index="${index}"]`);
    const nameCell = row.querySelector('.profile-name-cell');
    const emailCell = row.querySelector('.profile-email-cell');
    const actionsCell = row.querySelector('td:last-child');

    // Replace text with input fields
    nameCell.innerHTML = `<input type="text" class="profile-name-input" value="${escapeHtml(profile.name)}">`;
    emailCell.innerHTML = `<input type="email" class="profile-email-input" value="${escapeHtml(profile.email)}">`;
    actionsCell.innerHTML = `
      <div class="profile-actions">
        <button class="action-btn save-btn">Save</button>
        <button class="action-btn cancel-btn">Cancel</button>
      </div>
    `;
  });
}

/**
 * Save edited profile
 */
function saveProfile(index) {
  const row = document.querySelector(`tr[data-index="${index}"]`);
  const newName = row.querySelector('.profile-name-input').value.trim();
  const newEmail = row.querySelector('.profile-email-input').value.trim();

  if (!newName || !newEmail) {
    alert('Please fill in all fields');
    return;
  }

  chrome.storage.local.get(['savedProfiles'], (result) => {
    const profiles = result.savedProfiles || [];
    profiles[index] = { name: newName, email: newEmail };

    chrome.storage.local.set({ savedProfiles: profiles }, () => {
      loadProfiles();
    });
  });
}

/**
 * Cancel editing a profile
 */
function cancelEdit(index) {
  loadProfiles();
}

/**
 * Delete a profile
 */
function deleteProfile(index) {
  // Removed confirm dialog to debug issues
  console.log('🧠 LinkSage: Attempting to delete profile at index', index);

  chrome.storage.local.get(['savedProfiles'], (result) => {
    const profiles = result.savedProfiles || [];
    console.log('🧠 LinkSage: Current profiles before delete:', profiles.length);

    if (index >= 0 && index < profiles.length) {
      profiles.splice(index, 1);
      console.log('🧠 LinkSage: Profile deleted, new count:', profiles.length);

      chrome.storage.local.set({ savedProfiles: profiles }, () => {
        console.log('🧠 LinkSage: Storage updated, reloading profiles');
        loadProfiles();
      });
    } else {
      console.error('🧠 LinkSage: Invalid index for deletion:', index);
    }
  });
}

/**
 * Escape HTML special characters
 */
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

/**
 * Add a new profile (called from content script when Save Profile is clicked)
 */
function addProfile(name, email) {
  chrome.storage.local.get(['savedProfiles'], (result) => {
    const profiles = result.savedProfiles || [];

    // Check if profile already exists
    const exists = profiles.some(p => p.email === email);
    if (exists) {
      console.log('Profile already exists');
      return;
    }

    profiles.push({ name, email });
    chrome.storage.local.set({ savedProfiles: profiles }, () => {
      loadProfiles();
    });
  });
}

/**
 * Initialize Custom Message tab functionality
 */
function initializeCustomMessage() {
  const generateBtn = document.getElementById('generateMessageBtn');
  const copyBtn = document.getElementById('copyMessageBtn');
  const regenerateBtn = document.getElementById('regenerateBtn');

  // Check if we're on a profile page
  checkIfOnProfilePage();

  if (generateBtn) {
    generateBtn.addEventListener('click', generateCustomMessage);
  }

  if (copyBtn) {
    copyBtn.addEventListener('click', copyMessageToClipboard);
  }

  if (regenerateBtn) {
    regenerateBtn.addEventListener('click', generateCustomMessage);
  }
}

/**
 * Check if current page is a LinkedIn profile page
 */
function checkIfOnProfilePage() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    const isProfilePage = currentTab.url.includes('/in/') &&
      !currentTab.url.includes('/feed') &&
      !currentTab.url.includes('/messaging');

    const customMessageTab = document.querySelector('[data-tab="custom-message"]');
    const customMessagePane = document.getElementById('custom-message-tab');
    const generateBtn = document.getElementById('generateMessageBtn');

    if (!isProfilePage) {
      // Disable the tab and show message
      if (customMessageTab) {
        customMessageTab.style.opacity = '0.5';
        customMessageTab.style.cursor = 'not-allowed';
        customMessageTab.style.pointerEvents = 'none';
      }
      if (customMessagePane) {
        customMessagePane.innerHTML = `
          <div style="padding: 24px; text-align: center; color: #9ca3af;">
            <p style="font-size: 16px; margin-bottom: 8px;">📍 Profile Page Only</p>
            <p style="font-size: 14px;">This feature only works when viewing a LinkedIn profile.</p>
            <p style="font-size: 13px; margin-top: 12px; color: #d1d5db;">Navigate to a profile page to use this feature.</p>
          </div>
        `;
      }
    } else {
      // Enable the tab
      if (customMessageTab) {
        customMessageTab.style.opacity = '1';
        customMessageTab.style.cursor = 'pointer';
        customMessageTab.style.pointerEvents = 'auto';
      }
      if (generateBtn) {
        generateBtn.disabled = false;
      }
    }
  });
}

/**
 * Generate custom welcome message based on profile
 */
function generateCustomMessage() {
  const generateBtn = document.getElementById('generateMessageBtn');
  generateBtn.disabled = true;
  generateBtn.innerHTML = '<span class="btn-icon">✨</span><span>Generating...</span>';

  // Get profile data from the current page
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs[0]) {
      alert('Error: Could not find active tab');
      generateBtn.disabled = false;
      generateBtn.innerHTML = '<span class="btn-icon">✨</span><span>Generate Message</span>';
      return;
    }

    chrome.tabs.sendMessage(
      tabs[0].id,
      { action: 'extractProfileForMessage' },
      async (response) => {
        try {
          // Check for chrome errors
          if (chrome.runtime.lastError) {
            throw new Error(chrome.runtime.lastError.message || 'Failed to communicate with page');
          }

          if (!response) {
            throw new Error('No response from page. Make sure you are on a LinkedIn profile page.');
          }

          if (response.error) {
            throw new Error(response.error);
          }

          if (!response.profileData) {
            throw new Error('Could not extract profile data from the page');
          }

          const profileData = response.profileData;
          const profileName = profileData.Name || 'there';

          // Create prompt for AI based on profile data
          const prompt = `Generate a warm, personalized welcome message for ${profileName}.

Profile Information:
- Role: ${profileData.Headline || profileData['Current Role'] || 'Professional'}
- Location: ${profileData.Location || 'Not specified'}
- Skills: ${(profileData.Skills && profileData.Skills.length > 0) ? profileData.Skills.slice(0, 5).join(', ') : 'Not specified'}
- Experience: ${(profileData.Experience && profileData.Experience.length > 0) ? profileData.Experience.slice(0, 2).map(e => e.role).join(', ') : 'Not specified'}

The message should:
- Be friendly and professional
- Reference their name and expertise naturally
- Be concise (2-3 sentences max)
- Feel genuine and not generic
- Be suitable for a first connection message

Generate only the message, no additional text or formatting.`;

          // Call Backend AI Proxy
          const apiResponse = await callBackendAI({
            model: 'llama-3.3-70b-versatile',
            messages: [
              {
                role: 'user',
                content: prompt
              }
            ],
            max_tokens: 150,
            temperature: 0.7
          });

          const generatedMessage = apiResponse.choices[0].message.content.trim();


          // Display the message
          document.getElementById('generatedMessage').textContent = generatedMessage;
          document.getElementById('messagePreview').style.display = 'block';

          // Store the current message for copy functionality
          window.currentMessage = generatedMessage;

        } catch (error) {
          console.error('Error generating message:', error);
          alert('Error: ' + error.message);
        } finally {
          generateBtn.disabled = false;
          generateBtn.innerHTML = '<span class="btn-icon">✨</span><span>Generate Message</span>';
        }
      }
    );
  });
}

/**
 * Copy generated message to clipboard
 */
function copyMessageToClipboard() {
  if (!window.currentMessage) {
    alert('No message to copy');
    return;
  }

  navigator.clipboard.writeText(window.currentMessage).then(() => {
    const copyBtn = document.getElementById('copyMessageBtn');
    const originalText = copyBtn.innerHTML;
    copyBtn.innerHTML = '<span>✓</span><span>Copied!</span>';

    setTimeout(() => {
      copyBtn.innerHTML = originalText;
    }, 2000);
  }).catch(err => {
    console.error('Failed to copy:', err);
    alert('Failed to copy message');
  });
}

/**
 * Initialize Export CSV functionality
 */
function initializeExport() {
  const exportBtn = document.getElementById('exportCsvBtn');
  if (exportBtn) {
    exportBtn.addEventListener('click', exportProfilesToCSV);
  }
}

/**
 * Export saved profiles to CSV
 */
function exportProfilesToCSV() {
  const exportBtn = document.getElementById('exportCsvBtn');
  const originalText = exportBtn.innerHTML;

  exportBtn.disabled = true;
  exportBtn.innerHTML = '<span class="btn-icon">⏳</span><span>Exporting...</span>';

  chrome.storage.local.get(['savedProfiles'], (result) => {
    const profiles = result.savedProfiles || [];

    if (profiles.length === 0) {
      alert('No profiles to export!');
      exportBtn.disabled = false;
      exportBtn.innerHTML = originalText;
      return;
    }

    try {
      // Define CSV headers
      const headers = ['Name', 'Email', 'Headline', 'Location', 'Profile URL', 'Saved At'];

      // Convert profiles to CSV rows
      const csvRows = [headers.join(',')];

      profiles.forEach(profile => {
        const row = [
          escapeCsvField(profile.name),
          escapeCsvField(profile.email),
          escapeCsvField(profile.headline),
          escapeCsvField(profile.location),
          escapeCsvField(profile.profileUrl),
          escapeCsvField(profile.savedAt)
        ];
        csvRows.push(row.join(','));
      });

      const csvContent = csvRows.join('\n');

      // Create download link
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');

      link.setAttribute('href', url);
      link.setAttribute('download', `linksage_profiles_${new Date().toISOString().slice(0, 10)}.csv`);
      link.style.visibility = 'hidden';

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Success feedback
      exportBtn.innerHTML = '<span class="btn-icon">✓</span><span>Exported!</span>';
      setTimeout(() => {
        exportBtn.disabled = false;
        exportBtn.innerHTML = originalText;
      }, 2000);

    } catch (error) {
      console.error('Export error:', error);
      alert('Failed to export profiles');
      exportBtn.disabled = false;
      exportBtn.innerHTML = originalText;
    }
  });
}

/**
 * Escape fields for CSV format
 */
function escapeCsvField(field) {
  if (field === null || field === undefined) {
    return '';
  }
  const stringField = String(field);
  // Escape quotes and wrap in quotes if contains comma, quote or newline
  if (stringField.includes(',') || stringField.includes('"') || stringField.includes('\n')) {
    return `"${stringField.replace(/"/g, '""')}"`;
  }
  return stringField;
}


/**
 * Call backend AI proxy
 */
async function callBackendAI(payload) {
  const resp = await fetch(BACKEND_AI_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-extension-key': BACKEND_CLIENT_KEY
    },
    body: JSON.stringify(payload)
  });

  if (!resp.ok) {
    const errorText = await resp.text();
    console.error(`🧠 LinkSage: Backend error ${resp.status}`, errorText);

    let errorMessage = `Backend responded ${resp.status}`;
    try {
      const errorJson = JSON.parse(errorText);
      if (errorJson.error) {
        errorMessage = errorJson.error.message || errorJson.error;
      }
    } catch (e) {
      if (errorText.includes('<!DOCTYPE html>')) {
        errorMessage = 'Backend authentication failed. Please check Vercel settings.';
      } else {
        errorMessage = `Backend error: ${errorText.substring(0, 100)}`;
      }
    }
    throw new Error(errorMessage);
  }
  return resp.json();
}
