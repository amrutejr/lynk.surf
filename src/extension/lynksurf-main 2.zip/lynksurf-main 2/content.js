/**
 * LynkSurf Content Script
 * Detects LinkedIn comment boxes and injects AI-powered comment drafting button
 */

// Configuration
const GROQ_MODEL = 'llama-3.3-70b-versatile'; // Fast and powerful Groq model
const BACKEND_AI_ENDPOINT = 'https://linksurf-k5dc3qpuh-abhinavs-projects-938b3e6e.vercel.app/api/groq/chat'; // Replace with your deployed Vercel URL
const BACKEND_CLIENT_KEY = '45ed4e3181fe023c34841cebc858e28fb7fa3c8b1f5f016692b06e44bd7fd3bf'; // Set in Vercel env and here
const BUTTON_CHECK_INTERVAL = 2000; // Check for new comment boxes every 2 seconds
const PROCESSED_CLASS = 'linksage-processed';

// Track processed comment boxes and share boxes
const processedBoxes = new WeakSet();
const processedShareBoxes = new WeakSet();
const processedContainers = new WeakSet();

/**
 * Call backend AI proxy to avoid exposing API key in extension
 * @param {Object} payload - Request payload with model, messages, etc.
 * @returns {Promise<Object>} - API response
 */
async function callBackendAI(payload) {
  const resp = await fetch(BACKEND_AI_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-extension-key': BACKEND_CLIENT_KEY
    },
    body: JSON.stringify(payload)
  });

  if (!resp.ok) {
    const errorText = await resp.text();
    console.error(`🧠 LynkSurf: Backend error ${resp.status}`, errorText);

    let errorMessage = `Backend responded ${resp.status}`;
    try {
      const errorJson = JSON.parse(errorText);
      if (errorJson.error) {
        errorMessage = errorJson.error.message || errorJson.error;
      }
    } catch (e) {
      // If response is HTML (like Vercel Auth), use a generic message but log the HTML above
      if (errorText.includes('<!DOCTYPE html>')) {
        errorMessage = 'Backend authentication failed. Please check Vercel settings.';
      } else {
        errorMessage = `Backend error: ${errorText.substring(0, 100)}`;
      }
    }
    throw new Error(errorMessage);
  }
  return resp.json();
}

/**
 * Initialize the extension
 */
function init() {
  console.log('🧠 LynkSurf: Initialized on LinkedIn');

  // Start observing for comment boxes
  observeCommentBoxes();

  // Initial scan for existing comment boxes
  injectButtonsToCommentBoxes();

  // Start observing for share boxes
  observeShareBoxes();

  // Initial scan for existing share boxes
  injectPostEnhancer();

  // Initialize profile analyzer
  observeProfilePages();

  // Initial scan for profile page
  injectProfileAnalyzerButton();
}

/**
 * Observe DOM changes to detect new comment boxes
 */
function observeCommentBoxes() {
  const observer = new MutationObserver((mutations) => {
    injectButtonsToCommentBoxes();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Also check periodically
  setInterval(injectButtonsToCommentBoxes, BUTTON_CHECK_INTERVAL);
}

/**
 * Find all LinkedIn comment boxes and inject Auto Draft button
 */
function injectButtonsToCommentBoxes() {
  // LinkedIn comment boxes can have different structures - use multiple selectors
  // Start with a catch-all for contenteditable divs, then filter
  const allEditableDivs = document.querySelectorAll('[contenteditable="true"]');
  const commentBoxes = [];

  allEditableDivs.forEach(div => {
    // Skip if already processed
    if (div.classList.contains(PROCESSED_CLASS)) {
      return;
    }

    // Check if it's clearly NOT a share box (main post creation)
    const isShareBox = div.closest('.share-box') ||
      div.closest('[data-test-id*="share"]') ||
      div.closest('[class*="share-creation"]') ||
      div.closest('.share-box-feed-entry') ||
      div.getAttribute('data-test-id')?.includes('share');

    // Skip share boxes
    if (isShareBox) {
      return;
    }

    // Skip if this div is nested inside another contenteditable div
    const parentEditableDiv = div.parentElement?.closest('[contenteditable="true"]');
    if (parentEditableDiv && !parentEditableDiv.classList.contains(PROCESSED_CLASS)) {
      console.log(`🧠 LynkSurf: Skipping nested contenteditable div`);
      return;
    }

    commentBoxes.push(div);
    console.log(`🧠 LynkSurf: Found potential comment box`, div);
  });

  console.log(`🧠 LynkSurf: Found ${commentBoxes.length} textbox(es)`);

  commentBoxes.forEach((box, index) => {
    // Skip if already processed
    if (processedBoxes.has(box) || box.classList.contains(PROCESSED_CLASS)) {
      return;
    }

    console.log(`🧠 LynkSurf: Injecting button for box ${index + 1}`);
    injectAutoDraftButton(box);
    processedBoxes.add(box);
    box.classList.add(PROCESSED_CLASS);
  });
}

/**
 * Inject the Auto Draft and Comment Enhancer buttons next to a comment box
 * @param {HTMLElement} commentBox - The comment input box
 */
function injectAutoDraftButton(commentBox) {
  try {
    // Find the parent container - try multiple strategies
    let container = commentBox.closest('.comments-comment-box') ||
      commentBox.closest('.comments-comment-texteditor') ||
      commentBox.closest('.comments-comment-box-container') ||
      commentBox.closest('.comments-reply-box') ||
      commentBox.closest('[class*="comment"]') ||
      commentBox.closest('[class*="reply"]') ||
      commentBox.closest('article') ||
      commentBox.parentElement?.parentElement ||
      commentBox.parentElement;

    if (!container) {
      console.warn('🧠 LynkSurf: Could not find container for button');
      return;
    }

    // Skip if this container has already been processed
    if (processedContainers.has(container)) {
      console.log('🧠 LynkSurf: Container already processed, skipping');
      return;
    }

    // Check if buttons already exist in the entire container
    const existingButton = container.querySelector('.linksage-auto-draft-btn');
    if (existingButton) {
      console.log('🧠 LynkSurf: Buttons already exist, skipping');
      processedContainers.add(container);
      return;
    }

    console.log('🧠 LynkSurf: Found container, injecting buttons', container);
    processedContainers.add(container);

    // Create button container for both buttons
    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'linksage-button-container';

    // Create Auto Draft button
    const autoDraftButton = document.createElement('button');
    autoDraftButton.className = 'linksage-auto-draft-btn';
    autoDraftButton.innerHTML = '✨ Auto Draft';
    autoDraftButton.title = 'Generate AI comment';
    autoDraftButton.type = 'button';

    autoDraftButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleAutoDraft(commentBox, autoDraftButton);
    });

    // Create Comment Enhancer button
    const enhancerButton = document.createElement('button');
    enhancerButton.className = 'linksage-comment-enhancer-btn';
    enhancerButton.innerHTML = '🚀 Enhance';
    enhancerButton.title = 'Enhance existing comment with AI';
    enhancerButton.type = 'button';

    enhancerButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleCommentEnhancer(commentBox, enhancerButton);
    });

    // Append both buttons to container
    buttonContainer.appendChild(autoDraftButton);
    buttonContainer.appendChild(enhancerButton);

    // Try multiple insertion strategies
    const buttonGroup = container.querySelector('.comments-comment-box__button-group');
    const toolbar = container.querySelector('.ql-toolbar');
    const actionButtons = container.querySelector('[class*="action"]') ||
      container.querySelector('[class*="button"]');

    if (buttonGroup) {
      console.log('🧠 LynkSurf: Inserting into button group');
      buttonGroup.prepend(buttonContainer);
    } else if (toolbar) {
      console.log('🧠 LynkSurf: Inserting after toolbar');
      toolbar.after(buttonContainer);
    } else if (actionButtons) {
      console.log('🧠 LynkSurf: Inserting after action buttons');
      actionButtons.after(buttonContainer);
    } else {
      console.log('🧠 LynkSurf: Inserting after comment box');
      commentBox.after(buttonContainer);
    }

    console.log('🧠 LynkSurf: Buttons injected successfully ✓');
  } catch (error) {
    console.error('🧠 LynkSurf: Error injecting buttons', error);
  }
}

/**
 * Handle Auto Draft button click
 * @param {HTMLElement} commentBox - The comment input box
 * @param {HTMLElement} button - The Auto Draft button
 */
async function handleAutoDraft(commentBox, button) {
  try {
    // Update button state
    const originalText = button.innerHTML;
    button.innerHTML = '⏳ Generating...';
    button.disabled = true;

    // Extract post text
    const postText = extractPostText(commentBox);

    if (!postText) {
      throw new Error('Could not find post text. Please try again.');
    }

    console.log('🧠 LynkSurf: Extracted post text:', postText.substring(0, 100) + '...');

    // Get settings (tone preference and persona)
    const { commentTone, userPersona } = await chrome.storage.local.get(['commentTone', 'userPersona']);

    // Generate comment
    const generatedComment = await generateComment(postText, commentTone || 'professional', userPersona || '');

    console.log('🧠 LynkSurf: Generated comment:', generatedComment);

    // Insert comment into the box
    insertComment(commentBox, generatedComment);

    // Success feedback
    button.innerHTML = '✓ Done!';
    setTimeout(() => {
      button.innerHTML = originalText;
      button.disabled = false;
    }, 2000);

  } catch (error) {
    console.error('🧠 LynkSurf Error:', error);

    // Error feedback
    button.innerHTML = '✗ Error';
    alert(`LynkSurf Error: ${error.message}`);

    setTimeout(() => {
      button.innerHTML = '✨ Auto Draft';
      button.disabled = false;
    }, 2000);
  }
}

/**
 * Handle Comment Enhancer button click
 * @param {HTMLElement} commentBox - The comment input box
 * @param {HTMLElement} button - The Comment Enhancer button
 */
async function handleCommentEnhancer(commentBox, button) {
  try {
    // Get existing comment text
    const existingComment = commentBox.textContent.trim();

    if (!existingComment) {
      alert('Please write a comment first before enhancing it!');
      return;
    }

    // Update button state
    const originalText = button.innerHTML;
    button.innerHTML = '⏳ Enhancing...';
    button.disabled = true;

    // Extract post text for context
    const postText = extractPostText(commentBox);

    // Get settings
    const { commentTone, userPersona } = await chrome.storage.local.get(['commentTone', 'userPersona']);

    // Enhance the comment
    const enhancedComment = await enhanceCommentWithAI(existingComment, postText, commentTone || 'professional', userPersona || '');

    console.log('🧠 LynkSurf: Enhanced comment:', enhancedComment);

    // Insert enhanced comment into the box
    insertComment(commentBox, enhancedComment);

    // Success feedback
    button.innerHTML = '✓ Enhanced!';
    setTimeout(() => {
      button.innerHTML = originalText;
      button.disabled = false;
    }, 2000);

  } catch (error) {
    console.error('🧠 LynkSurf Error:', error);

    // Error feedback
    button.innerHTML = '✗ Error';
    alert(`Comment Enhancer Error: ${error.message}`);

    setTimeout(() => {
      button.innerHTML = '🚀 Enhance';
      button.disabled = false;
    }, 2000);
  }
}

/**
 * Enhance existing comment using AI
 * @param {string} comment - The existing comment
 * @param {string} postText - The post text for context
 * @param {string} tone - Comment tone
 * @param {string} userPersona - User's persona
 * @returns {Promise<string>} - Enhanced comment
 */
async function enhanceCommentWithAI(comment, postText, tone, userPersona) {
  const toneInstructions = {
    professional: 'Make it more professional, insightful, and impactful while maintaining the core message.',
    friendly: 'Make it warmer, more engaging, and conversational while keeping the original sentiment.',
    thoughtful: 'Make it more reflective, nuanced, and thought-provoking while preserving the main idea.'
  };

  const personaContext = userPersona ? `\nUser Persona: ${userPersona}` : '';

  const systemPrompt = `You are an expert LinkedIn engagement assistant specializing in enhancing comments.

Your task is to improve an existing LinkedIn comment by:
1. Making it more impactful and engaging
2. Improving grammar and clarity
3. Adding relevant insights or perspectives
4. Keeping it concise (under 50 words)
5. Maintaining the original intent and tone${personaContext}

Guidelines:
- ${toneInstructions[tone] || toneInstructions.professional}
- Keep it authentic and human-like
- Do not change the core message
- Avoid hashtags unless already present
- Output only the enhanced comment, no explanations
- Do NOT include any quotation marks or quotes in your response
- Return ONLY the enhanced comment text, nothing else`;

  const requestBody = {
    model: GROQ_MODEL,
    messages: [
      {
        role: 'system',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Original comment: "${comment}"${postText ? `\n\nPost context: ${postText.substring(0, 200)}` : ''}\n\nPlease enhance this comment.`
      }
    ],
    temperature: 0.7,
    max_tokens: 100,
    top_p: 0.9,
    stream: false
  };

  const data = await callBackendAI(requestBody);
  let enhancedText = data.choices?.[0]?.message?.content;

  if (!enhancedText) {
    throw new Error('No enhanced comment generated from API');
  }

  // Remove surrounding quotes if present
  enhancedText = enhancedText.trim();
  if ((enhancedText.startsWith('"') && enhancedText.endsWith('"')) ||
    (enhancedText.startsWith("'") && enhancedText.endsWith("'"))) {
    enhancedText = enhancedText.slice(1, -1);
  }

  return enhancedText;
}

/**
 * Extract the post text (caption) from the LinkedIn post
 * @param {HTMLElement} commentBox - The comment input box
 * @returns {string|null} - The post text or null if not found
 */
function extractPostText(commentBox) {
  // Find the post container - try multiple strategies
  let postContainer = commentBox.closest('.feed-shared-update-v2') ||
    commentBox.closest('[data-urn]') ||
    commentBox.closest('article') ||
    commentBox.closest('[class*="feed"]') ||
    commentBox.closest('[class*="update"]');

  if (!postContainer) {
    console.warn('🧠 LynkSurf: Could not find post container, trying parent traversal');
    // Try going up the DOM tree to find any parent that might contain post text
    let parent = commentBox.parentElement;
    let depth = 0;
    while (parent && depth < 10) {
      const text = parent.innerText?.trim() || '';
      if (text.length > 50) {
        postContainer = parent;
        break;
      }
      parent = parent.parentElement;
      depth++;
    }
  }

  if (!postContainer) {
    console.warn('🧠 LynkSurf: Could not find post container after traversal');
    return null;
  }

  // Try different selectors for post text
  const selectors = [
    '.feed-shared-update-v2__description',
    '.feed-shared-text',
    '.feed-shared-inline-show-more-text',
    '[data-test-id="main-feed-activity-card__commentary"]',
    '.update-components-text',
    '[class*="description"]',
    '[class*="text"]'
  ];

  for (const selector of selectors) {
    const element = postContainer.querySelector(selector);
    if (element) {
      // Get text content, removing extra whitespace
      const text = element.innerText.trim();
      if (text.length > 10) {
        console.log('🧠 LynkSurf: Found post text with selector:', selector);
        return text;
      }
    }
  }

  // Fallback: try to get any text from the post, excluding the comment box itself
  const allText = postContainer.innerText.trim();
  if (allText.length > 50) {
    console.log('🧠 LynkSurf: Using fallback post text extraction');
    return allText.substring(0, 500); // Limit to 500 chars
  }

  console.warn('🧠 LynkSurf: Could not extract any meaningful post text');
  return null;
}

/**
 * Generate comment using Groq API
 * @param {string} postText - The LinkedIn post text
 * @param {string} tone - Comment tone (professional, friendly, thoughtful)
 * @param {string} userPersona - User's persona description
 * @returns {Promise<string>} - Generated comment
 */
async function generateComment(postText, tone, userPersona) {
  // Build prompt based on tone
  const toneInstructions = {
    professional: 'Respond with a concise, respectful, and insightful tone that fits a corporate or industry discussion.',
    friendly: 'Respond in a warm, conversational, and supportive manner that feels genuine and approachable.',
    thoughtful: 'Respond in a reflective, insightful way that adds value or gently invites further discussion.'
  };

  // Build persona context
  const personaContext = userPersona ? `
User Persona Context: ${userPersona}

Consider this persona when crafting the comment to make it more personalized and authentic to their background and experience.
` : '';

  const systemPrompt = `
You are an intelligent LinkedIn engagement assistant.

Your task is to craft a short, authentic, and context-aware LinkedIn comment (under 40 words) for the post caption provided by the user.

${personaContext}
Guidelines:
1. Make the comment directly relevant to the post's theme — avoid generic reactions.
2. Keep it grammatically perfect, natural, and easy to read.
3. ${toneInstructions[tone] || toneInstructions.professional}
4. Sound human — no exaggerated praise, marketing talk, or robotic phrasing.
5. Do not repeat the post text; instead, add perspective, agreement, or a brief reaction.
6. Avoid hashtags, emojis, or links unless they already appear in the post.
7. Output only the final comment, no explanations or formatting.
8. Make it more humanized
9. No double inverted commas or single inverted commas while returning output

Your goal: Write a concise, human-like comment that would fit naturally on LinkedIn and feel written by a real professional user.
`;
  const requestBody = {
    model: GROQ_MODEL,
    messages: [
      {
        role: 'system',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Write a LinkedIn comment for this post:\n\n${postText}`
      }
    ],
    temperature: 0.7,
    max_tokens: 100,
    top_p: 0.9,
    stream: false
  };

  const data = await callBackendAI(requestBody);

  // Extract generated text from Groq response
  const generatedText = data.choices?.[0]?.message?.content;

  if (!generatedText) {
    throw new Error('No response generated from API');
  }

  return generatedText.trim();
}

/**
 * Insert generated comment into the comment box
 * @param {HTMLElement} commentBox - The comment input box
 * @param {string} comment - The generated comment
 */
function insertComment(commentBox, comment) {
  // Focus the comment box
  commentBox.focus();

  // Clear existing content
  commentBox.innerHTML = '';

  // Create a text node to insert the comment
  const textNode = document.createTextNode(comment);
  commentBox.appendChild(textNode);

  // Set the text content as well for compatibility
  commentBox.textContent = comment;

  // Trigger input event to notify LinkedIn
  const inputEvent = new Event('input', { bubbles: true });
  commentBox.dispatchEvent(inputEvent);

  // Also trigger change event
  const changeEvent = new Event('change', { bubbles: true });
  commentBox.dispatchEvent(changeEvent);

  // Trigger keydown and keyup events for better compatibility
  const keydownEvent = new KeyboardEvent('keydown', { bubbles: true });
  commentBox.dispatchEvent(keydownEvent);

  const keyupEvent = new KeyboardEvent('keyup', { bubbles: true });
  commentBox.dispatchEvent(keyupEvent);

  console.log('🧠 LynkSurf: Comment inserted successfully');
}

/**
 * Observe DOM changes to detect share boxes
 */
function observeShareBoxes() {
  const observer = new MutationObserver((mutations) => {
    injectPostEnhancer();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Also check periodically
  setInterval(injectPostEnhancer, BUTTON_CHECK_INTERVAL);
}

/**
 * Find LinkedIn share boxes and inject Post Enhancer button
 */
function injectPostEnhancer() {
  // PRIORITY 1: Check for share-box directly (covers all share box types)
  const shareBoxes = document.querySelectorAll('.share-box');
  shareBoxes.forEach((shareBox) => {
    if (!processedShareBoxes.has(shareBox)) {
      console.log('🧠 LinkSage: Found .share-box, attempting to inject button');
      injectPostEnhancerButton(null, shareBox);
      processedShareBoxes.add(shareBox);
    }
  });

  // PRIORITY 2: Check for artdeco-carousel__content directly in the document
  const carouselContents = document.querySelectorAll('.artdeco-carousel__content');
  carouselContents.forEach((carousel) => {
    if (!processedShareBoxes.has(carousel)) {
      const shareBoxParent = carousel.closest('[data-test-modal-id="share-box-modal"]') ||
        carousel.closest('[role="dialog"][class*="share-box"]') ||
        carousel.closest('.artdeco-modal[class*="share-box"]') ||
        carousel.closest('.share-creation-state') ||
        carousel.closest('.share-box');
      if (shareBoxParent) {
        console.log('🧠 LinkSage: Found artdeco-carousel__content, injecting button');
        injectPostEnhancerButton(carousel, shareBoxParent);
        processedShareBoxes.add(carousel);
      }
    }
  });

  // PRIORITY 3: Look for share-creation-state
  const creationStates = document.querySelectorAll('.share-creation-state');
  creationStates.forEach((state) => {
    if (!processedShareBoxes.has(state)) {
      const shareBox = state.closest('.share-box') || state.closest('[data-test-modal-id="share-box-modal"]');
      if (shareBox && !processedShareBoxes.has(shareBox)) {
        console.log('🧠 LinkSage: Found .share-creation-state, injecting button');
        injectPostEnhancerButton(null, shareBox);
        processedShareBoxes.add(shareBox);
      }
    }
  });

  // PRIORITY 4: Look for the share box modal/container - updated selectors to catch new modal structure
  const modals = document.querySelectorAll(
    '[data-test-modal-id="share-box-modal"], ' +
    '[role="dialog"][class*="share-box"], ' +
    '.artdeco-modal[class*="share-box"]'
  );

  modals.forEach((modal) => {
    if (!processedShareBoxes.has(modal)) {
      console.log('🧠 LinkSage: Found share box modal, injecting button');
      injectPostEnhancerButton(null, modal);
      processedShareBoxes.add(modal);
    }
  });
}

/**
 * Create the Enhance Post button with styles and events
 * @returns {HTMLElement} The button element
 */
function createEnhanceButton() {
  const button = document.createElement('button');
  button.className = 'linksage-post-enhancer-btn';
  button.type = 'button';
  button.title = 'Post Enhancer';
  button.setAttribute('aria-label', 'Post Enhancer');

  // Create button content with magic wand icon and text
  button.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="linksage-magic-wand-icon">
      <path d="M15 4V2"/>
      <path d="M15 16v-2"/>
      <path d="M8 9h2"/>
      <path d="M20 9h2"/>
      <path d="M17.8 11.8 19 13"/>
      <path d="M15 9h0"/>
      <path d="M17.8 6.2 19 5"/>
      <path d="m3 21 9-9"/>
      <path d="M12.2 6.2 11 5"/>
    </svg>
    <span>Enhance</span>
  `;

  // Apply custom premium styles directly to ensure they work in Shadow DOM
  Object.assign(button.style, {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    padding: '8px 16px',
    borderRadius: '20px',
    background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    position: 'relative',
    margin: '0 8px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
    fontSize: '14px',
    fontWeight: '600',
    boxShadow: '0 4px 12px rgba(99, 102, 241, 0.3)',
    height: '32px',
    width: 'auto',
    zIndex: '1000'
  });

  // Add hover effects via JS
  button.addEventListener('mouseenter', () => {
    button.style.background = 'linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)';
    button.style.boxShadow = '0 6px 16px rgba(99, 102, 241, 0.4)';
    button.style.transform = 'translateY(-1px)';
    const icon = button.querySelector('svg');
    if (icon) icon.style.transform = 'rotate(-15deg) scale(1.1)';
  });

  button.addEventListener('mouseleave', () => {
    button.style.background = 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)';
    button.style.boxShadow = '0 4px 12px rgba(99, 102, 241, 0.3)';
    button.style.transform = 'translateY(0)';
    const icon = button.querySelector('svg');
    if (icon) icon.style.transform = 'none';
  });

  return button;
}

/**
 * Inject Post Enhancer button into share box actions
 * @param {HTMLElement} actionsContainer - The actions container
 * @param {HTMLElement} shareBox - The share box element
 */
function injectPostEnhancerButton(actionsContainer, shareBox) {
  // Check if button already exists
  const existingButton = shareBox.querySelector('.linksage-post-enhancer-btn');
  if (existingButton) {
    console.log('🧠 LinkSage: Button already exists, skipping');
    return;
  }

  console.log('🧠 LinkSage: Injecting Post Enhancer button into share box');

  // PRIORITY 1: Check for the redesigned footer container
  const footerContainer = shareBox.querySelector('.share-creation-state__schedule-and-post-container');
  if (footerContainer) {
    console.log('🧠 LinkSage: Found share-creation-state__schedule-and-post-container, injecting button there');

    // Create a wrapper for our button to sit nicely next to the other actions
    const buttonWrapper = document.createElement('div');
    buttonWrapper.className = 'linksage-share-footer-btn-wrapper';
    buttonWrapper.style.cssText = `
      display: flex;
      align-items: center;
      margin-right: 8px;
    `;

    // Create the button (simplified creation for this context)
    const button = createEnhanceButton();
    buttonWrapper.appendChild(button);

    // Insert before the share box actions (Post button)
    // Insert after the schedule clock button if it exists
    const scheduleClock = footerContainer.querySelector('.share-creation-state__schedule-clock-btn');
    const shareActions = footerContainer.querySelector('.share-box_actions');

    if (scheduleClock) {
      console.log('🧠 LinkSage: Found schedule clock, inserting after it');
      scheduleClock.after(buttonWrapper);
    } else if (shareActions) {
      console.log('🧠 LinkSage: Schedule clock not found, inserting before share actions');
      footerContainer.insertBefore(buttonWrapper, shareActions);
    } else {
      footerContainer.appendChild(buttonWrapper);
    }

    // Add click handler
    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handlePostEnhancer(shareBox, button);
    });

    return;
  }

  // PRIORITY 2: Try to find the update-components-actor__container (Old Design)
  let targetContainer = shareBox.querySelector('.update-components-actor__container');

  if (targetContainer) {
    console.log('🧠 LinkSage: Found update-components-actor__container, injecting button there');
    injectButtonIntoContainer(targetContainer, shareBox);
    return;
  }

  // Fallback: Find the text editor container to place button below it
  let textEditor = shareBox.querySelector('.ql-editor');

  if (!textEditor) {
    textEditor = shareBox.querySelector('[contenteditable="true"]');
  }

  if (!textEditor) {
    textEditor = shareBox.querySelector('[role="textbox"]');
  }

  if (!textEditor) {
    console.warn('🧠 LinkSage: Could not find text editor in share box. Available elements:', shareBox.innerHTML.substring(0, 500));
    return;
  }

  console.log('🧠 LinkSage: Found text editor:', textEditor.className);

  // Try multiple selectors to find the editor container
  let editorContainer = textEditor?.closest('.editor-container') ||
    textEditor?.closest('.ql-container') ||
    textEditor?.closest('[class*="editor"]') ||
    textEditor?.closest('[class*="text"]') ||
    textEditor?.parentElement?.parentElement ||
    textEditor?.parentElement;

  console.log('🧠 LinkSage: Found editor container:', editorContainer?.className);

  // Create a wrapper div for the button
  const buttonWrapper = document.createElement('div');
  buttonWrapper.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 12px 16px;
    background: #ffffff;
    border-top: 1px solid #ffffff;
    gap: 8px;
  `;

  // Create the button
  const button = createEnhanceButton();

  // Add click handler
  button.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    handlePostEnhancer(shareBox, button);
  });

  // Append button to wrapper
  buttonWrapper.appendChild(button);

  // Insert the wrapper below the text editor if found
  if (editorContainer && editorContainer.parentElement) {
    // Try to insert right after the editor container
    editorContainer.parentElement.insertBefore(buttonWrapper, editorContainer.nextSibling);
    console.log('🧠 LinkSage: Post Enhancer button injected below editor ✓');
  } else if (textEditor && textEditor.parentElement) {
    // Fallback: insert after the text editor itself
    textEditor.parentElement.insertBefore(buttonWrapper, textEditor.nextSibling);
    console.log('🧠 LinkSage: Post Enhancer button injected after text editor ✓');
  } else if (actionsContainer) {
    // Last resort: append to actions container
    actionsContainer.appendChild(buttonWrapper);
    console.log('🧠 LinkSage: Post Enhancer button appended to actions container ✓');
  } else {
    // Final fallback: append to share box
    shareBox.appendChild(buttonWrapper);
    console.log('🧠 LinkSage: Post Enhancer button appended to share box ✓');
  }

  console.log('🧠 LinkSage: Post Enhancer button injected successfully ✓');
}

/**
 * Inject button directly into a specific container
 * @param {HTMLElement} container - The target container
 * @param {HTMLElement} shareBox - The share box element
 */
function injectButtonIntoContainer(container, shareBox) {
  // Create the button
  const button = document.createElement('button');
  button.className = 'linksage-post-enhancer-btn';
  button.type = 'button';
  button.title = 'Post Enhancer';
  button.setAttribute('aria-label', 'Post Enhancer');

  // Create button content with magic wand icon and text
  button.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="linksage-magic-wand-icon" style="width: 18px; height: 18px; flex-shrink: 0;">
      <path d="M15 4V2"/>
      <path d="M15 16v-2"/>
      <path d="M8 9h2"/>
      <path d="M20 9h2"/>
      <path d="M17.8 11.8 19 13"/>
      <path d="M15 9h0"/>
      <path d="M17.8 6.2 19 5"/>
      <path d="m3 21 9-9"/>
      <path d="M12.2 6.2 11 5"/>
    </svg>
    <span>Enhance</span>
  `;

  // Apply custom styles to button
  button.style.cssText = `
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 18px;
    background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 2px 8px rgba(139, 92, 246, 0.3);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    letter-spacing: 0.3px;
  `;

  // Add hover effect
  button.addEventListener('mouseenter', () => {
    button.style.background = 'linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%)';
    button.style.boxShadow = '0 4px 10px rgba(139, 92, 246, 0.35)';
    button.style.transform = 'translateY(-1px)';
  });

  button.addEventListener('mouseleave', () => {
    button.style.background = 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)';
    button.style.boxShadow = '0 2px 8px rgba(139, 92, 246, 0.3)';
    button.style.transform = 'translateY(0)';
  });

  // Add click handler
  button.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    handlePostEnhancer(shareBox, button);
  });

  // Append button to container
  container.appendChild(button);
  console.log('🧠 LinkSage: Post Enhancer button injected into update-components-actor__container ✓');
}

/**
 * Handle Post Enhancer button click
 * @param {HTMLElement} shareBox - The share box element
 * @param {HTMLElement} button - The Post Enhancer button
 */
async function handlePostEnhancer(shareBox, button) {
  try {
    console.log('🧠 LynkSurf: Post Enhancer clicked');

    // Find the post text editor
    const textEditor = shareBox.querySelector('.ql-editor, [role="textbox"][contenteditable="true"]') ||
      document.querySelector('[data-test-modal-id="share-box-modal"] .ql-editor, [data-test-modal-id="share-box-modal"] [role="textbox"][contenteditable="true"]');

    if (!textEditor) {
      alert('Could not find the post editor!');
      return;
    }

    // Get current text
    const currentText = textEditor.textContent.trim();

    // Check if there's text to enhance
    if (!currentText) {
      alert('Please write something in the post first before enhancing it!');
      return;
    }

    // Update button state - show loading spinner
    const originalHTML = button.innerHTML;
    const originalTitle = button.title;
    button.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px; animation: spin 1s linear infinite;">
        <circle cx="12" cy="12" r="10"/>
      </svg>
      <span>Enhancing...</span>
    `;
    button.title = 'Enhancing post...';
    button.disabled = true;

    // Get user settings
    const { commentTone, userPersona } = await chrome.storage.local.get(['commentTone', 'userPersona']);

    // Call AI to enhance the post
    const enhancedPost = await enhancePostWithAI(currentText, commentTone || 'professional', userPersona || '');

    // Insert enhanced post
    textEditor.focus();
    textEditor.innerHTML = '';

    // Create a text node to insert the enhanced post
    const textNode = document.createTextNode(enhancedPost);
    textEditor.appendChild(textNode);

    // Set the text content as well for compatibility
    textEditor.textContent = enhancedPost;

    // Trigger input events
    const inputEvent = new Event('input', { bubbles: true });
    textEditor.dispatchEvent(inputEvent);

    // Also trigger change event
    const changeEvent = new Event('change', { bubbles: true });
    textEditor.dispatchEvent(changeEvent);

    // Trigger keydown and keyup events for better compatibility
    const keydownEvent = new KeyboardEvent('keydown', { bubbles: true });
    textEditor.dispatchEvent(keydownEvent);

    const keyupEvent = new KeyboardEvent('keyup', { bubbles: true });
    textEditor.dispatchEvent(keyupEvent);

    // Success feedback - show checkmark
    button.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;">
        <polyline points="20 6 9 17 4 12"/>
      </svg>
      <span>Enhanced!</span>
    `;
    button.title = 'Post enhanced!';
    setTimeout(() => {
      button.innerHTML = originalHTML;
      button.title = originalTitle;
      button.disabled = false;
    }, 2000);

  } catch (error) {
    console.error('🧠 LynkSurf Error:', error);
    alert(`Post Enhancer Error: ${error.message}`);

    // Reset button - show X mark
    button.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 18px; height: 18px;">
        <line x1="18" y1="6" x2="6" y2="18"/>
        <line x1="6" y1="6" x2="18" y2="18"/>
      </svg>
      <span>Error</span>
    `;
    button.title = 'Error occurred';
    setTimeout(() => {
      button.innerHTML = originalHTML;
      button.title = originalTitle;
      button.disabled = false;
    }, 2000);
  }
}

/**
 * Enhance existing post using AI
 * @param {string} post - The existing post text
 * @param {string} tone - Post tone
 * @param {string} userPersona - User's persona
 * @returns {Promise<string>} - Enhanced post
 */
async function enhancePostWithAI(post, tone, userPersona) {
  const toneInstructions = {
    professional: 'Make it more professional, impactful, and authoritative while maintaining authenticity.',
    friendly: 'Make it warmer, more engaging, and conversational while keeping the original message.',
    thoughtful: 'Make it more reflective, nuanced, and thought-provoking while preserving the main idea.'
  };

  const personaContext = userPersona ? `\nUser Persona: ${userPersona}` : '';

  const systemPrompt = `You are an expert LinkedIn content enhancement specialist.

Your task is to improve an existing LinkedIn post by:
1. Making it more impactful and engaging
2. Improving grammar, clarity, and flow
3. Adding relevant insights or perspectives
4. Maintaining authenticity and human voice
5. Keeping it concise and scannable${personaContext}

Guidelines:
- ${toneInstructions[tone] || toneInstructions.professional}
- Keep it authentic and human-like
- Do not change the core message or intent
- Preserve the original structure if it works well
- Avoid hashtags unless already present
- Output only the enhanced post, no explanations
- Do NOT include any quotation marks or quotes in your response
- Return ONLY the enhanced post text, nothing else`;

  const requestBody = {
    model: GROQ_MODEL,
    messages: [
      {
        role: 'system',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Original post: "${post}"\n\nPlease enhance this post to make it more impactful and engaging.`
      }
    ],
    temperature: 0.7,
    max_tokens: 500,
    top_p: 0.9,
    stream: false
  };

  const data = await callBackendAI(requestBody);
  let enhancedText = data.choices?.[0]?.message?.content;

  if (!enhancedText) {
    throw new Error('No enhanced post generated from API');
  }

  // Remove surrounding quotes if present
  enhancedText = enhancedText.trim();
  if ((enhancedText.startsWith('"') && enhancedText.endsWith('"')) ||
    (enhancedText.startsWith("'") && enhancedText.endsWith("'"))) {
    enhancedText = enhancedText.slice(1, -1);
  }

  return enhancedText;
}

/**
 * Generate post content using AI based on topic/idea
 * @param {string} topic - The topic or idea for the post
 * @param {string} tone - The desired tone
 * @returns {Promise<string>} Generated post text
 */
async function generatePostWithAI(topic, tone) {
  const prompt = `You are a LinkedIn content creation expert. Create an engaging, professional LinkedIn post based on the following topic or idea.

Topic/Idea: ${topic}

Tone: ${tone}

Instructions:
- Create a complete, well-structured LinkedIn post
- Make it engaging and authentic
- Use appropriate emojis sparingly (only if they enhance the message)
- Include a hook to grab attention
- Add value or insights
- Keep it concise (150-250 words ideal)
- Use line breaks for readability
- End with a call-to-action or thought-provoking question if appropriate
- Match the ${tone} tone throughout
- Make it sound natural and human, not robotic
- DO NOT add hashtags unless specifically requested in the topic
- DO NOT wrap the post in quotes or inverted commas
- Output only the post content, no explanations or formatting

Write the complete post now:`;

  const data = await callBackendAI({
    model: GROQ_MODEL,
    messages: [
      {
        role: 'system',
        content: 'You are an expert LinkedIn content creator who writes engaging, authentic posts that resonate with professional audiences. You understand storytelling, value creation, and audience engagement.'
      },
      {
        role: 'user',
        content: prompt
      }
    ],
    temperature: 0.8,
    max_tokens: 600
  });
  let generatedPost = data.choices[0]?.message?.content?.trim();

  if (!generatedPost) {
    throw new Error('No post generated');
  }

  // Remove surrounding quotes if present
  if ((generatedPost.startsWith('"') && generatedPost.endsWith('"')) ||
    (generatedPost.startsWith("'") && generatedPost.endsWith("'"))) {
    generatedPost = generatedPost.slice(1, -1);
  }

  return generatedPost;
}

/**
 * ==============================================
 * PROFILE ANALYZER FEATURE
 * ==============================================
 */

/**
 * Check if current page is a LinkedIn profile page
 */
function isProfilePage() {
  const path = window.location.pathname;
  const isProfile = (path.includes('/in/') || path.includes('/profile/')) &&
    !path.includes('/feed') &&
    !path.includes('/messaging') &&
    !path.includes('/jobs/') &&
    !path.includes('/overlay/');

  if (isProfile) {
    console.log('🧠 LynkSurf: Detected profile page:', window.location.href);
  }
  return isProfile;
}

// ... (keep extractProfileData and other functions as is) ...

// Track if button injection has been attempted
let profileButtonInjected = false;

/**
 * Add profile analyzer button to LinkedIn profile page
 */
function injectProfileAnalyzerButton() {
  if (!isProfilePage()) {
    profileButtonInjected = false;
    return;
  }

  // Check if button already exists (either inline or floating)
  if (document.querySelector('.linksage-profile-analyzer-btn') ||
    document.querySelector('.linksage-profile-analyzer-floating')) {
    return;
  }

  // Only log once per page
  if (!profileButtonInjected) {
    console.log('🧠 LynkSurf: Attempting to inject Profile Analyzer button');
  }

  // Try multiple selectors for the profile actions section
  // Updated with more recent LinkedIn DOM structures
  const selectors = [
    '.pv-top-card-v2-ctas',
    '.pvs-profile-actions',
    '.pv-top-card--list',
    '.artdeco-card .pv-top-card__cta-container',
    'section.artdeco-card .ph5 .pv-top-card-v2-ctas',
    '.scaffold-layout__main section:first-child .pv-top-card-v2-ctas',
    '.ph5 .display-flex.mt2', // Generic container often used for actions
    '.pv-top-card__actions'
  ];

  let actionsSection = null;
  for (const selector of selectors) {
    actionsSection = document.querySelector(selector);
    if (actionsSection) {
      console.log(`🧠 LynkSurf: Found actions section with selector: ${selector}`);
      break;
    }
  }

  // Create button
  const button = document.createElement('button');
  button.className = 'linksage-profile-analyzer-btn';
  button.innerHTML = '🧠 Analyze Profile';
  button.title = 'Extract and analyze profile data';
  button.type = 'button';

  // Add specific styles to ensure visibility
  button.style.zIndex = '99';
  button.style.position = 'relative';

  button.addEventListener('click', async (e) => {
    e.preventDefault();
    e.stopPropagation();

    const originalText = button.innerHTML;
    button.innerHTML = '⏳ Analyzing...';
    button.disabled = true;

    try {
      const profileData = await extractProfileData();
      displayProfileOverlay(profileData);
    } catch (error) {
      console.error('🧠 LynkSurf: Profile analysis error:', error);
      alert('Failed to analyze profile. Please try again.');
    }

    button.innerHTML = originalText;
    button.disabled = false;
  });

  if (!actionsSection) {
    // Fallback: Create floating button if standard location not found
    if (!profileButtonInjected) {
      console.warn('🧠 LynkSurf: Could not find profile actions section, using floating button');
    }
    button.classList.add('linksage-profile-analyzer-floating');
    // Remove inline styles that might conflict with floating class
    button.style.position = '';
    button.style.zIndex = '';
    button.style.margin = '';

    document.body.appendChild(button);
    if (!profileButtonInjected) {
      console.log('🧠 LynkSurf: Profile Analyzer floating button injected ✓');
    }
  } else {
    // Standard injection into profile actions
    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'linksage-profile-btn-container'; // Add class for potential styling
    buttonContainer.appendChild(button);

    // Try to append at the end of the actions list
    actionsSection.appendChild(buttonContainer);

    if (!profileButtonInjected) {
      console.log('🧠 LynkSurf: Profile Analyzer button injected successfully ✓');
    }
  }

  profileButtonInjected = true;
}

/**
 * Extract LinkedIn profile data and analyze for CRM enrichment
 */
async function extractProfileData() {
  const profileData = {
    "Name": "",
    "ProfileUrl": window.location.href,
    "Current Role": "",
    "Headline": "",
    "Skills": [],
    "Interests": [],
    "Experience": [],
    "Education": [],
    "Accomplishments": [],
    "Location": "",
    "Contact Info": {
      "Email": [],
      "Phone": [],
      "Company Website": ""
    },
    "Summary": ""
  };

  try {
    // Extract Name
    const nameElement = document.querySelector('h1.text-heading-xlarge, h1.inline.t-24');
    if (nameElement) {
      profileData.Name = nameElement.textContent.trim();
    }

    // Extract Headline
    const headlineElement = document.querySelector('.text-body-medium.break-words, .pv-text-details__left-panel .text-body-medium');
    if (headlineElement) {
      profileData.Headline = headlineElement.textContent.trim();
    }

    // Extract Location
    const locationElement = document.querySelector('.text-body-small.inline.t-black--light.break-words, span.text-body-small:not(.break-words)');
    if (locationElement) {
      profileData.Location = locationElement.textContent.trim();
    }

    // Extract About/Summary
    const aboutSection = document.querySelector('#about')?.closest('section');
    if (aboutSection) {
      const aboutText = aboutSection.querySelector('.inline-show-more-text, .pv-shared-text-with-see-more');
      if (aboutText) {
        profileData.Summary = aboutText.textContent.trim();
      }
    }

    // Extract Experience
    const experienceSection = document.querySelector('#experience')?.closest('section');
    if (experienceSection) {
      const experienceItems = experienceSection.querySelectorAll('li.artdeco-list__item');
      experienceItems.forEach(item => {
        const roleElement = item.querySelector('.mr1.t-bold span[aria-hidden="true"]');
        const companyElement = item.querySelector('.t-14.t-normal span[aria-hidden="true"]');
        const durationElement = item.querySelector('.t-14.t-normal.t-black--light span[aria-hidden="true"]');

        if (roleElement) {
          const exp = {
            role: roleElement.textContent.trim(),
            company: companyElement ? companyElement.textContent.trim() : '',
            duration: durationElement ? durationElement.textContent.trim() : ''
          };
          profileData.Experience.push(exp);

          // Extract current role
          if (profileData.Experience.length === 1) {
            profileData["Current Role"] = `${exp.role} at ${exp.company}`;
          }
        }
      });
    }

    // Extract Education
    const educationSection = document.querySelector('#education')?.closest('section');
    if (educationSection) {
      const educationItems = educationSection.querySelectorAll('li.artdeco-list__item');
      educationItems.forEach(item => {
        const schoolElement = item.querySelector('.mr1.hoverable-link-text.t-bold span[aria-hidden="true"]');
        const degreeElement = item.querySelector('.t-14.t-normal span[aria-hidden="true"]');

        if (schoolElement) {
          profileData.Education.push({
            school: schoolElement.textContent.trim(),
            degree: degreeElement ? degreeElement.textContent.trim() : ''
          });
        }
      });
    }

    // Extract Skills - Enhanced to fetch all skills
    const skillsSection = document.querySelector('#skills')?.closest('section');
    if (skillsSection) {
      // First get visible skills
      const skillItems = skillsSection.querySelectorAll('.mr1.hoverable-link-text.t-bold span[aria-hidden="true"], .pvs-entity__path span[aria-hidden="true"]');
      skillItems.forEach(skill => {
        const skillText = skill.textContent.trim();
        if (skillText && !profileData.Skills.includes(skillText)) {
          profileData.Skills.push(skillText);
        }
      });

      // Try to fetch ALL skills from the details page
      try {
        const currentUrl = window.location.href;
        // Construct skills URL (works for /in/username and /in/username/)
        let skillsUrl = currentUrl;
        if (skillsUrl.endsWith('/')) skillsUrl = skillsUrl.slice(0, -1);

        // Handle if we are already on a sub-page
        if (skillsUrl.includes('/details/')) {
          skillsUrl = skillsUrl.split('/details/')[0];
        }

        skillsUrl += '/details/skills/';

        console.log('🧠 LynkSurf: Fetching all skills from:', skillsUrl);
        const allSkills = await fetchAllSkills(skillsUrl);

        if (allSkills.length > 0) {
          console.log(`🧠 LynkSurf: Found ${allSkills.length} skills from details page`);
          // Merge and deduplicate
          allSkills.forEach(skill => {
            if (!profileData.Skills.includes(skill)) {
              profileData.Skills.push(skill);
            }
          });
        }
      } catch (e) {
        console.warn('🧠 LynkSurf: Could not fetch extra skills:', e);
      }
    }

    // Extract Interests/Topics from Activity section
    const activitySection = document.querySelector('#interests, [data-view-name*="interests"]');
    if (activitySection) {
      const interestItems = activitySection.querySelectorAll('.hoverable-link-text, .t-bold span');
      interestItems.forEach(interest => {
        const interestText = interest.textContent.trim();
        if (interestText && interestText.length > 2 && !profileData.Interests.includes(interestText)) {
          profileData.Interests.push(interestText);
        }
      });
    }

    // Extract Accomplishments
    const accomplishmentsSection = document.querySelector('#accomplishments, [data-view-name*="accomplishments"]')?.closest('section');
    if (accomplishmentsSection) {
      const accomplishmentItems = accomplishmentsSection.querySelectorAll('.pvs-entity__path, .mr1.hoverable-link-text');
      accomplishmentItems.forEach(item => {
        const text = item.textContent.trim();
        if (text && text.length > 3 && !profileData.Accomplishments.includes(text)) {
          profileData.Accomplishments.push(text);
        }
      });
    }

    // Infer interests from headline and summary
    if (!profileData.Interests.length) {
      const inferredInterests = inferInterestsFromProfile(profileData);
      profileData.Interests = inferredInterests;
    }

    // Extract Contact Info
    const contactSection = document.querySelector('#top-card-text-details-contact-info, a[href*="overlay/contact-info"]');
    if (contactSection) {
      // Try to click and extract from modal
      contactSection.click();
      await new Promise(resolve => setTimeout(resolve, 500));

      const contactModal = document.querySelector('[role="dialog"]');
      if (contactModal) {
        // Extract email
        const emailElements = contactModal.querySelectorAll('a[href^="mailto:"]');
        emailElements.forEach(el => {
          const email = el.href.replace('mailto:', '');
          if (email) {
            profileData["Contact Info"].Email.push({
              value: email,
              confidence: "High"
            });
          }
        });

        // Extract phone
        const phoneElements = contactModal.querySelectorAll('.pv-contact-info__ci-container');
        phoneElements.forEach(el => {
          const text = el.textContent;
          const phoneMatch = text.match(/[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,9}/);
          if (phoneMatch) {
            profileData["Contact Info"].Phone.push({
              value: phoneMatch[0],
              confidence: "High"
            });
          }
        });

        // Extract website
        const websiteElements = contactModal.querySelectorAll('a[href]:not([href^="mailto:"])');
        websiteElements.forEach(el => {
          const url = el.href;
          if (url && !url.includes('linkedin.com')) {
            profileData["Contact Info"]["Company Website"] = url;
          }
        });

        // Close modal
        const closeButton = contactModal.querySelector('button[aria-label*="Dismiss"]');
        if (closeButton) closeButton.click();
      }
    }

    // Infer email if not found
    if (profileData["Contact Info"].Email.length === 0) {
      const inferredEmails = inferEmailAddresses(profileData);
      profileData["Contact Info"].Email = inferredEmails;
    }

    // Extract company domain for email inference
    if (profileData["Current Role"] && profileData["Contact Info"]["Company Website"] === "") {
      const companyMatch = profileData["Current Role"].match(/at (.+)/);
      if (companyMatch) {
        const company = companyMatch[1].trim();
        profileData["Contact Info"]["Company Website"] = inferCompanyDomain(company);
      }
    }

  } catch (error) {
    console.error('🧠 LynkSurf Profile Analyzer Error:', error);
  }

  return profileData;
}

/**
 * Infer interests from profile data using keywords
 */
function inferInterestsFromProfile(profileData) {
  const interests = [];
  const text = `${profileData.Headline} ${profileData.Summary}`.toLowerCase();

  // Common interest keywords
  const interestKeywords = {
    'AI': ['ai', 'artificial intelligence', 'machine learning', 'deep learning'],
    'Technology': ['tech', 'software', 'programming', 'coding'],
    'Business': ['business', 'entrepreneurship', 'startup', 'venture'],
    'Marketing': ['marketing', 'branding', 'advertising', 'social media'],
    'Design': ['design', 'ux', 'ui', 'creative'],
    'Data Science': ['data science', 'analytics', 'big data'],
    'Leadership': ['leadership', 'management', 'team building'],
    'Innovation': ['innovation', 'disruption', 'transformation'],
    'SaaS': ['saas', 'cloud', 'software as a service'],
    'Finance': ['finance', 'investment', 'fintech', 'banking']
  };

  for (const [interest, keywords] of Object.entries(interestKeywords)) {
    if (keywords.some(keyword => text.includes(keyword))) {
      interests.push(interest);
    }
  }

  return interests.slice(0, 5); // Limit to 5 interests
}

/**
 * Generate AI summary of the profile
 */
async function generateAISummary(profileData) {
  const prompt = `Analyze this LinkedIn profile and provide a concise professional summary (2-3 sentences):

Name: ${profileData.Name}
Role: ${profileData["Current Role"] || profileData.Headline}
Experience: ${profileData.Experience.slice(0, 3).map(e => `${e.role} at ${e.company}`).join(', ')}
Skills: ${profileData.Skills.slice(0, 10).join(', ')}
Education: ${profileData.Education.map(e => `${e.degree} from ${e.school}`).join(', ')}

Write a professional summary highlighting their expertise, background, and key strengths.`;

  try {
    const data = await callBackendAI({
      model: GROQ_MODEL,
      messages: [
        {
          role: 'system',
          content: 'You are a professional LinkedIn profile analyst. Create concise, accurate summaries.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 150
    });

    return data.choices[0]?.message?.content?.trim() || '';
  } catch (error) {
    console.error('🧠 LynkSurf: AI summary error:', error);
    return '';
  }
}

/**
 * Fetch all skills from the skills details page
 * @param {string} url - The URL of the skills details page
 * @returns {Promise<Array>} - Array of skill strings
 */
async function fetchAllSkills(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) return [];

    const html = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    const skills = [];

    // Selectors for the skills list on the details page
    // LinkedIn uses different structures, try to catch them
    const skillElements = doc.querySelectorAll(
      '.pvs-list__paged-list-item .mr1.hoverable-link-text.t-bold span[aria-hidden="true"], ' +
      '.pvs-list__paged-list-item .t-bold span[aria-hidden="true"]'
    );

    skillElements.forEach(el => {
      const text = el.textContent.trim();
      if (text && !skills.includes(text)) {
        skills.push(text);
      }
    });

    return skills;
  } catch (error) {
    console.error('🧠 LynkSurf: Error fetching skills page:', error);
    return [];
  }
}

/**
 * Infer email addresses based on name and company
 */
function inferEmailAddresses(profileData) {
  const emails = [];

  // Clean name - remove emojis and special characters
  const cleanName = profileData.Name
    .replace(/[^\w\s\-]/g, '') // Remove emojis and special chars
    .replace(/\s+/g, ' ')       // Normalize spaces
    .trim()
    .toLowerCase();

  const nameParts = cleanName.split(' ').filter(part => part.length > 0);

  if (nameParts.length < 2) {
    console.log('🧠 LynkSurf: Cannot infer email - insufficient name parts');
    return emails;
  }

  const firstName = nameParts[0];
  const lastName = nameParts[nameParts.length - 1];
  const firstInitial = firstName.charAt(0);

  // Validate name parts (must be alphabetic)
  if (!/^[a-z]+$/.test(firstName) || !/^[a-z]+$/.test(lastName)) {
    console.log('🧠 LynkSurf: Cannot infer email - invalid name format');
    return emails;
  }

  // Extract domain from company website or infer from company name
  let domain = '';
  if (profileData["Contact Info"]["Company Website"]) {
    try {
      const url = new URL(profileData["Contact Info"]["Company Website"]);
      domain = url.hostname.replace('www.', '');
    } catch (e) {
      domain = profileData["Contact Info"]["Company Website"].replace(/^https?:\/\/(www\.)?/, '').split('/')[0];
    }
  } else if (profileData["Current Role"]) {
    const companyMatch = profileData["Current Role"].match(/at (.+)/);
    if (companyMatch) {
      domain = inferCompanyDomain(companyMatch[1].trim());
    }
  }

  if (domain && domain.includes('.')) {
    // Common email patterns
    emails.push({
      value: `${firstName}.${lastName}@${domain}`,
      confidence: "Medium"
    });
    emails.push({
      value: `${firstName}@${domain}`,
      confidence: "Low"
    });
    emails.push({
      value: `${firstInitial}${lastName}@${domain}`,
      confidence: "Low"
    });
  } else {
    console.log('🧠 LynkSurf: Cannot infer email - no valid domain found');
  }

  return emails;
}

/**
 * Infer company domain from company name
 */
function inferCompanyDomain(companyName) {
  const cleanName = companyName.toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[^a-z0-9]/g, '');

  // Common company mappings
  const knownDomains = {
    'google': 'google.com',
    'microsoft': 'microsoft.com',
    'apple': 'apple.com',
    'amazon': 'amazon.com',
    'meta': 'meta.com',
    'facebook': 'meta.com',
    'netflix': 'netflix.com',
    'tesla': 'tesla.com',
    'deepmind': 'deepmind.google'
  };

  return knownDomains[cleanName] || `${cleanName}.com`;
}

/**
 * Display profile analysis in overlay
 */
function displayProfileOverlay(profileData) {
  // Remove existing overlay
  const existingOverlay = document.querySelector('.linksage-profile-overlay');
  if (existingOverlay) {
    existingOverlay.remove();
  }

  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = 'linksage-profile-overlay';
  overlay.innerHTML = `
    <div class="linksage-overlay-header">
      <h3>✨ LynkSurf Profile Analysis</h3>
      <button class="linksage-overlay-close" title="Close">×</button>
    </div>
    <div class="linksage-overlay-content">
      <div id="profileContent">Loading AI analysis...</div>
    </div>
    <div class="linksage-overlay-footer">
      <button class="linksage-generate-summary" style="margin-right: 10px;">✨ Generate AI Summary</button>
      <button class="linksage-save-profile">💾 Save Profile</button>
    </div>
  `;

  document.body.appendChild(overlay);

  // Add event listeners
  overlay.querySelector('.linksage-overlay-close').addEventListener('click', () => {
    overlay.remove();
  });

  overlay.querySelector('.linksage-save-profile').addEventListener('click', async () => {
    const button = overlay.querySelector('.linksage-save-profile');
    const originalText = button.innerHTML;

    button.innerHTML = '<span class="btn-icon">⏳</span><span>Saving...</span>';
    button.disabled = true;

    try {
      // Get existing profiles from storage
      const { savedProfiles = [] } = await chrome.storage.local.get('savedProfiles');

      // Extract the best email from contact info
      let email = '';
      if (profileData["Contact Info"] && profileData["Contact Info"].Email && profileData["Contact Info"].Email.length > 0) {
        email = profileData["Contact Info"].Email[0].value || '';
      }

      // If no email found, use inferred emails
      if (!email && profileData["Contact Info"] && profileData["Contact Info"].Email && profileData["Contact Info"].Email.length > 0) {
        email = profileData["Contact Info"].Email[0].value || '';
      }

      // Fallback: generate a placeholder email from name if no email found
      if (!email && profileData.Name) {
        const nameParts = profileData.Name.toLowerCase().split(' ');
        if (nameParts.length >= 2) {
          email = `${nameParts[0]}.${nameParts[nameParts.length - 1]}@linkedin.com`;
        } else {
          email = `${nameParts[0]}@linkedin.com`;
        }
      }

      // Create profile object matching the structure expected by popup.js
      const newProfile = {
        name: profileData.Name || 'Unknown',
        email: email || 'no-email@linkedin.com',
        headline: profileData.Headline || '',
        location: profileData.Location || '',
        profileUrl: window.location.href,
        savedAt: new Date().toISOString()
      };

      // Check for duplicates based on email (more reliable check)
      const exists = savedProfiles.some(p => p.email === newProfile.email && p.email !== '');
      if (exists) {
        button.innerHTML = '<span class="btn-icon">⚠️</span><span>Already Saved</span>';
        setTimeout(() => {
          button.innerHTML = originalText;
          button.disabled = false;
        }, 2000);
        return;
      }

      // Add to saved profiles
      savedProfiles.push(newProfile);

      console.log('🧠 LinkSage: About to save profiles. Total profiles:', savedProfiles.length);
      console.log('🧠 LinkSage: New profile being saved:', newProfile);
      console.log('🧠 LinkSage: All profiles to save:', savedProfiles);

      // Save to storage
      await chrome.storage.local.set({ savedProfiles });

      // Verify save was successful
      const verification = await chrome.storage.local.get('savedProfiles');
      console.log('🧠 LinkSage: Verification - profiles in storage after save:', verification.savedProfiles);

      console.log('🧠 LinkSage: Profile saved successfully:', newProfile);

      // Notify popup if it's open
      chrome.runtime.sendMessage({ action: 'profileSaved' }).catch(() => {
        // Popup might not be open, that's okay
      });

      button.innerHTML = '<span class="btn-icon">✓</span><span>Profile Saved!</span>';
      setTimeout(() => {
        button.innerHTML = originalText;
        button.disabled = false;
      }, 2000);
    } catch (error) {
      console.error('🧠 LynkSurf: Save profile error:', error);
      button.innerHTML = '<span class="btn-icon">✗</span><span>Save Failed</span>';
      setTimeout(() => {
        button.innerHTML = originalText;
        button.disabled = false;
      }, 2000);
    }
  });

  // Add listener for Generate AI Summary
  overlay.querySelector('.linksage-generate-summary').addEventListener('click', async () => {
    const button = overlay.querySelector('.linksage-generate-summary');
    const originalText = button.innerHTML;

    button.innerHTML = '<span class="btn-icon">⏳</span><span>Generating...</span>';
    button.disabled = true;

    try {
      const summary = await generateAISummary(profileData);

      if (summary) {
        // Insert summary at the top of the content
        const contentDiv = overlay.querySelector('#profileContent');
        const summaryHtml = `
          <div class="profile-section summary-section" style="background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border-left: 4px solid #0ea5e9;">
            <h3 class="section-title">✨ AI Professional Summary</h3>
            <p class="profile-summary">${escapeHTML(summary)}</p>
          </div>
        `;

        // Check if summary section already exists and replace it, otherwise prepend
        const existingSummary = contentDiv.querySelector('.summary-section');
        if (existingSummary) {
          existingSummary.outerHTML = summaryHtml;
        } else {
          // Insert after header section if it exists, otherwise prepend
          const headerSection = contentDiv.querySelector('.profile-header-section');
          if (headerSection) {
            headerSection.insertAdjacentHTML('afterend', summaryHtml);
          } else {
            contentDiv.insertAdjacentHTML('afterbegin', summaryHtml);
          }
        }

        button.innerHTML = '<span class="btn-icon">✓</span><span>Summary Generated!</span>';
      } else {
        button.innerHTML = '<span class="btn-icon">⚠️</span><span>Failed</span>';
      }
    } catch (error) {
      console.error('🧠 LynkSurf: Summary generation error:', error);
      button.innerHTML = '<span class="btn-icon">✗</span><span>Error</span>';
    }

    setTimeout(() => {
      button.innerHTML = originalText;
      button.disabled = false;
    }, 2000);
  });

  // Generate AI analysis
  generateProfileAnalysis(profileData, overlay);
}

/**
 * Generate AI-powered profile analysis
 */
async function generateProfileAnalysis(profileData, overlay) {
  const contentDiv = overlay.querySelector('#profileContent');

  try {
    // Create prompt for comprehensive analysis
    const prompt = `Analyze this LinkedIn profile and provide insights in JSON format:

Name: ${profileData.Name}
Headline: ${profileData.Headline}
Current Role: ${profileData['Current Role']}
Location: ${profileData.Location}
Skills: ${profileData.Skills.slice(0, 10).join(', ')}
Experience: ${profileData.Experience.slice(0, 3).map(e => e.role).join(', ')}
Summary: ${profileData.Summary}

Provide a JSON response with this exact structure:
{
  "style": "One word describing their professional style (e.g., Casual, Professional, Innovative)",
  "tone": "One word describing their communication tone (e.g., Friendly, Formal, Bold)",
  "strengths": ["strength 1", "strength 2", "strength 3"],
  "areasToImprove": ["area 1", "area 2"],
  "suggestedImprovements": ["suggestion 1", "suggestion 2", "suggestion 3"]
}

Return ONLY valid JSON, no other text.`;

    const data = await callBackendAI({
      model: GROQ_MODEL,
      messages: [
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 500,
      temperature: 0.7
    });
    const analysisText = data.choices[0]?.message?.content?.trim() || '';

    // Parse JSON response
    const analysis = JSON.parse(analysisText);

    // Build HTML
    let html = `
      <div class="profile-header-section">
        <h2 class="profile-name">${escapeHTML(profileData.Name)}</h2>
        <p class="profile-headline">${escapeHTML(profileData.Headline || profileData['Current Role'] || 'Professional')}</p>
      </div>

      <div class="profile-style-tone">
        <div class="style-box">
          <div class="style-label">Style</div>
          <div class="style-value">${escapeHTML(analysis.style || 'Professional')}</div>
        </div>
        <div class="tone-box">
          <div class="tone-label">Tone</div>
          <div class="tone-value">${escapeHTML(analysis.tone || 'Professional')}</div>
        </div>
      </div>

      <div class="profile-section strengths-section">
        <h3 class="section-title">📈 Strengths</h3>
        <ul class="strengths-list">
    `;

    if (analysis.strengths && Array.isArray(analysis.strengths)) {
      analysis.strengths.forEach(strength => {
        html += `<li><span class="checkmark">✓</span>${escapeHTML(strength)}</li>`;
      });
    }

    html += `
        </ul>
      </div>

      <div class="profile-section areas-section">
        <h3 class="section-title">⚠️ Areas to Improve</h3>
        <ul class="areas-list">
    `;

    if (analysis.areasToImprove && Array.isArray(analysis.areasToImprove)) {
      analysis.areasToImprove.forEach(area => {
        html += `<li><span class="bullet">•</span>${escapeHTML(area)}</li>`;
      });
    }

    html += `
        </ul>
      </div>

      <div class="profile-section suggestions-section">
        <h3 class="section-title">💡 Suggested Improvements</h3>
        <div class="suggestions-list">
    `;

    if (analysis.suggestedImprovements && Array.isArray(analysis.suggestedImprovements)) {
      analysis.suggestedImprovements.forEach(suggestion => {
        html += `<div class="suggestion-box">${escapeHTML(suggestion)}</div>`;
      });
    }

    html += `
        </div>
      </div>
    `;

    contentDiv.innerHTML = html;

  } catch (error) {
    console.error('🧠 LynkSurf: Profile analysis error:', error);
    contentDiv.innerHTML = `
      <div class="error-message">
        <p>⚠️ Failed to generate AI analysis</p>
        <p style="font-size: 13px; color: #666;">${error.message}</p>
      </div>
    `;
  }
}

/**
 * Escape HTML special characters
 */
function escapeHTML(text) {
  if (!text) return '';
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return String(text).replace(/[&<>"']/g, char => map[char]);
}

/**
 * Format profile data into readable HTML
 */
function formatProfileData(data) {
  const cleanName = data.Name.replace(/[^\w\s\-]/g, '').trim() || 'Unknown';

  let html = `
    <div class="profile-section">
      <div class="profile-header-section">
        <h2 class="profile-name">${escapeHTML(data.Name) || 'Unknown'}</h2>
        ${data.Location ? `<p class="profile-location">📍 ${escapeHTML(data.Location.split('\n')[0])}</p>` : ''}
      </div>
    </div>
  `;

  // Current Role & Headline
  if (data["Current Role"] || data.Headline) {
    html += `
      <div class="profile-section">
        <h3 class="section-title">💼 Professional Info</h3>
        ${data["Current Role"] ? `<p><strong>Current Role:</strong> ${escapeHTML(data["Current Role"])}</p>` : ''}
        ${data.Headline ? `<p><strong>Headline:</strong> ${escapeHTML(data.Headline)}</p>` : ''}
      </div>
    `;
  }

  // Summary
  if (data.Summary) {
    html += `
      <div class="profile-section">
        <h3 class="section-title">📝 About</h3>
        <p class="profile-summary">${escapeHTML(data.Summary)}</p>
      </div>
    `;
  }

  // Contact Info
  if (data["Contact Info"]) {
    const contact = data["Contact Info"];
    const hasContact = contact.Email?.length > 0 || contact.Phone?.length > 0 || contact["Company Website"];

    if (hasContact) {
      html += `
        <div class="profile-section">
          <h3 class="section-title">📧 Contact Information</h3>
      `;

      // Email
      if (contact.Email && contact.Email.length > 0) {
        html += `<div class="contact-group"><strong>Email:</strong><ul class="contact-list">`;
        contact.Email.forEach(email => {
          const confidenceBadge = `<span class="confidence-badge confidence-${email.confidence.toLowerCase()}">${escapeHTML(email.confidence)}</span>`;
          html += `<li>${escapeHTML(email.value)} ${confidenceBadge}</li>`;
        });
        html += `</ul></div>`;
      }

      // Phone
      if (contact.Phone && contact.Phone.length > 0) {
        html += `<div class="contact-group"><strong>Phone:</strong><ul class="contact-list">`;
        contact.Phone.forEach(phone => {
          const confidenceBadge = `<span class="confidence-badge confidence-${phone.confidence.toLowerCase()}">${escapeHTML(phone.confidence)}</span>`;
          html += `<li>${escapeHTML(phone.value)} ${confidenceBadge}</li>`;
        });
        html += `</ul></div>`;
      }

      // Website
      if (contact["Company Website"]) {
        html += `<div class="contact-group"><strong>Website:</strong> <a href="${escapeHTML(contact["Company Website"])}" target="_blank">${escapeHTML(contact["Company Website"])}</a></div>`;
      }

      html += `</div>`;
    }
  }

  // Experience
  if (data.Experience && data.Experience.length > 0) {
    html += `
      <div class="profile-section">
        <h3 class="section-title">💼 Experience</h3>
        <ul class="experience-list">
    `;
    data.Experience.forEach(exp => {
      html += `
        <li class="experience-item">
          <strong>${escapeHTML(exp.role)}</strong>
          ${exp.company ? `<br><span class="company-name">${escapeHTML(exp.company)}</span>` : ''}
          ${exp.duration ? `<br><span class="duration">${escapeHTML(exp.duration)}</span>` : ''}
        </li>
      `;
    });
    html += `</ul></div>`;
  }

  // Education
  if (data.Education && data.Education.length > 0) {
    html += `
      <div class="profile-section">
        <h3 class="section-title">🎓 Education</h3>
        <ul class="education-list">
    `;
    data.Education.forEach(edu => {
      html += `
        <li class="education-item">
          <strong>${escapeHTML(edu.school)}</strong>
          ${edu.degree ? `<br><span class="degree">${escapeHTML(edu.degree)}</span>` : ''}
        </li>
      `;
    });
    html += `</ul></div>`;
  }

  // Skills
  if (data.Skills && data.Skills.length > 0) {
    html += `
      <div class="profile-section">
        <h3 class="section-title">🛠️ Skills</h3>
        <div class="skills-container">
    `;
    data.Skills.forEach(skill => {
      html += `<span class="skill-tag">${escapeHTML(skill)}</span>`;
    });

    // Add View All Skills button
    let skillsUrl = data.ProfileUrl || window.location.href;
    if (skillsUrl.endsWith('/')) skillsUrl = skillsUrl.slice(0, -1);
    if (skillsUrl.includes('/details/')) skillsUrl = skillsUrl.split('/details/')[0];
    skillsUrl += '/details/skills/';

    html += `</div>
      <div style="margin-top: 12px; text-align: center;">
        <a href="${escapeHTML(skillsUrl)}" target="_blank" class="linksage-view-all-skills" style="display: inline-block; padding: 6px 12px; background: #f3f4f6; color: #4b5563; text-decoration: none; border-radius: 4px; font-size: 12px; font-weight: 500; transition: all 0.2s;">
          View All Skills on LinkedIn ↗
        </a>
      </div>
    </div>`;
  }

  // Interests
  if (data.Interests && data.Interests.length > 0) {
    html += `
      <div class="profile-section">
        <h3 class="section-title">💡 Interests</h3>
        <div class="interests-container">
    `;
    data.Interests.forEach(interest => {
      html += `<span class="interest-tag">${escapeHTML(interest)}</span>`;
    });
    html += `</div></div>`;
  }

  // Accomplishments
  if (data.Accomplishments && data.Accomplishments.length > 0) {
    html += `
      <div class="profile-section">
        <h3 class="section-title">🏆 Accomplishments</h3>
        <ul class="accomplishments-list">
    `;
    data.Accomplishments.forEach(accomplishment => {
      html += `<li>${escapeHTML(accomplishment)}</li>`;
    });
    html += `</ul></div>`;
  }

  // Empty state message
  if (!data["Current Role"] && !data.Headline && !data.Summary &&
    (!data.Experience || data.Experience.length === 0) &&
    (!data.Education || data.Education.length === 0) &&
    (!data.Skills || data.Skills.length === 0)) {
    html += `
      <div class="profile-section empty-state">
        <p>⚠️ Limited profile data available. This may be due to privacy settings or the profile structure.</p>
        <p>Click "✨ Generate AI Summary" to create an intelligent overview based on available data.</p>
      </div>
    `;
  }

  return html;
}

/**
 * Observe DOM changes to detect profile pages
 */
function observeProfilePages() {
  // Debounce to prevent excessive calls
  let debounceTimer;

  const observer = new MutationObserver((mutations) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      try {
        injectProfileAnalyzerButton();
      } catch (error) {
        console.error('🧠 LynkSurf: Error in profile observer:', error);
      }
    }, 500);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Also check periodically (less frequently)
  setInterval(() => {
    try {
      injectProfileAnalyzerButton();
    } catch (error) {
      console.error('🧠 LynkSurf: Error in profile interval:', error);
    }
  }, 5000);
}

/**
 * Convert profiles array to CSV format
 * @param {Array} profiles - Array of profile objects
 * @returns {string} - CSV formatted string
 */
function convertProfilesToCSV(profiles) {
  if (!profiles || profiles.length === 0) {
    return '';
  }

  // Define CSV headers
  const headers = [
    'Name',
    'Current Role',
    'Headline',
    'Location',
    'Summary',
    'Skills',
    'Interests',
    'Experience',
    'Education',
    'Email Addresses',
    'Phone Numbers',
    'Company Website',
    'Saved At'
  ];

  // Escape CSV values
  const escapeCSV = (value) => {
    if (!value) return '';
    const stringValue = String(value);
    if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
      return `"${stringValue.replace(/"/g, '""')}"`;
    }
    return stringValue;
  };

  // Convert array to comma-separated string
  const arrayToString = (arr) => {
    if (Array.isArray(arr)) {
      return arr.map(item => {
        if (typeof item === 'object') {
          return item.value || item.role || item.school || item.degree || String(item);
        }
        return String(item);
      }).join('; ');
    }
    return String(arr);
  };

  // Create header row
  let csv = headers.map(escapeCSV).join(',') + '\n';

  // Create data rows
  profiles.forEach(profile => {
    const row = [
      profile.Name || '',
      profile['Current Role'] || '',
      profile.Headline || '',
      profile.Location || '',
      profile.Summary || '',
      arrayToString(profile.Skills || []),
      arrayToString(profile.Interests || []),
      arrayToString(profile.Experience || []),
      arrayToString(profile.Education || []),
      arrayToString(profile['Contact Info']?.Email || []),
      arrayToString(profile['Contact Info']?.Phone || []),
      profile['Contact Info']?.['Company Website'] || '',
      profile.savedAt || new Date().toISOString()
    ];

    csv += row.map(escapeCSV).join(',') + '\n';
  });

  return csv;
}

/**
 * Handle messages from popup
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractProfileForMessage') {
    // Extract profile data for custom message generation
    extractProfileData().then(profileData => {
      sendResponse({ profileData });
    }).catch(error => {
      console.error('Error extracting profile:', error);
      sendResponse({ error: error.message });
    });
    return true; // Keep the message channel open for async response
  }
});

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
