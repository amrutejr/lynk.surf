# 🧠 LynkSurf - AI-Powered LinkedIn Comment Assistant

LynkSurf is a Chrome Extension that helps you draft AI-generated comments directly inside the LinkedIn UI using Groq's ultra-fast AI API. It serves as an AI-powered LinkedIn comment assistant for professional, engaging interactions.

## ✨ Features

- **Zero Configuration**: Works immediately after installation - no API key needed!
- **Auto Comment Drafter**: Automatically generates contextual comments based on LinkedIn post content
- **Ultra-Fast AI**: Uses Groq's LLaMA 3.3 70B model for instant responses (<1 second)
- **Tone Selection**: Choose between Professional, Friendly, or Thoughtful comment tones
- **Seamless Integration**: Button appears directly in LinkedIn's comment boxes
- **Privacy-Focused**: No data collection or tracking

## 🚀 Installation

### Step 1: Install the Extension (No API Key Needed!)

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top-right corner)
4. Click "Load unpacked"
5. Select the `linksage` folder
6. The LynkSurf icon should appear in your Chrome toolbar

### Step 2: Start Using It!

1. Go to [LinkedIn.com](https://www.linkedin.com)
2. Find any post and click the comment box
3. Click the **"✨ Auto Draft"** button
4. AI comment appears instantly!

### Step 3: Customize Tone (Optional)

1. Click the LynkSurf icon in your Chrome toolbar
2. Select your preferred comment tone (Professional, Friendly, or Thoughtful)
3. Click "Save Settings"

**No API key needed!** The extension is pre-configured and ready to use.

## 📖 How to Use

1. **Navigate to LinkedIn**: Go to [linkedin.com](https://www.linkedin.com)
2. **Find a Post**: Scroll through your feed and find a post you want to comment on
3. **Click Comment Box**: Click on the comment input box below any post
4. **Look for the Button**: You'll see a blue "✨ Auto Draft" button appear
5. **Generate Comment**: Click the button and wait a few seconds
6. **Review & Post**: The AI-generated comment will appear in the box - review it, edit if needed, and post!

## 🎯 Comment Tones

- **Professional**: Business-appropriate, formal tone suitable for networking
- **Friendly**: Warm, approachable tone for casual engagement
- **Thoughtful**: Insightful, reflective tone for deeper discussions

## 🛠️ Technical Details

### Built With

- **Manifest V3**: Latest Chrome Extension standard
- **Groq with LLaMA 3.3 70B**: Ultra-fast inference with powerful open-source models
- **Vanilla JavaScript**: No frameworks, pure ES6+
- **Chrome Storage API**: Secure local storage for API keys

### File Structure

```
linksage/
├── manifest.json          # Extension configuration
├── content.js            # Main logic for detecting and injecting buttons
├── popup.html            # Settings UI
├── popup.js              # Settings logic
├── styles.css            # LinkedIn-style button styling
├── icons/
│   ├── icon128.png       # Extension icon
│   ├── create_icon.py    # Icon generator script
│   └── generate_icon.html # Browser-based icon generator
└── README.md             # This file
```

### Permissions

- `activeTab`: Access to the current LinkedIn tab
- `scripting`: Inject content scripts
- `storage`: Store API key and settings locally
- `https://generativelanguage.googleapis.com/*`: Access to Gemini API
- `https://www.linkedin.com/*`: Access to LinkedIn pages

## 🔒 Privacy & Security

- Your API key is stored locally in your browser using `chrome.storage.local`
- No data is sent to any server except Google's Gemini API
- Post content is only sent to Gemini for comment generation
- No tracking, analytics, or data collection

## 🐛 Troubleshooting

### Button Not Appearing

- Make sure you're on linkedin.com
- Try refreshing the page
- Check that the extension is enabled in `chrome://extensions/`
- Look in the browser console (F12) for any error messages

### API Errors

- Verify your API key is correct in the extension popup
- Check that your API key has not expired
- Ensure you have API quota remaining in Google AI Studio
- Check your internet connection

### Comment Not Inserting

- Try clicking the comment box first to focus it
- Refresh the page and try again
- Check browser console for errors

## 📝 Development

### Debugging

The extension logs helpful information to the browser console:

```javascript
// Open DevTools (F12) and look for messages like:
🧠 LynkSurf: Initialized on LinkedIn
🧠 LynkSurf: Button injected
🧠 LynkSurf: Extracted post text: ...
🧠 LynkSurf: Generated comment: ...
```

### Modifying the AI Prompt

Edit the `generateComment()` function in `content.js` to customize the prompt sent to Gemini.

### Styling

Modify `styles.css` to change the button appearance.

## 🎨 Icon Generation

If you need to regenerate the icon:

**Option 1: Python Script**
```bash
cd icons
python3 create_icon.py
```

**Option 2: Browser**
```bash
# Open icons/generate_icon.html in a browser
# Right-click the canvas and "Save Image As..." -> icon128.png
```

## 📄 License

This project is provided as-is for educational and personal use.

## 🤝 Contributing

Feel free to fork, modify, and improve this extension!

## ⚠️ Disclaimer

This extension is not affiliated with, endorsed by, or sponsored by LinkedIn or Google. Use responsibly and in accordance with LinkedIn's Terms of Service.

## 🆘 Support

If you encounter issues:

1. Check the Troubleshooting section above
2. Review browser console logs (F12)
3. Verify your API key and settings
4. Try reinstalling the extension

---

**Made with 🧠 LynkSurf for better LinkedIn engagement**
